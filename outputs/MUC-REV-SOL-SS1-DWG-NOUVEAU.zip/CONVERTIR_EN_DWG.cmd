@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0convertir-en-dwg.ps1"
if errorlevel 1 (
  echo.
  echo La conversion a echoue. Verifiez qu AutoCAD est installe puis relancez ce fichier.
) else (
  echo.
  echo Conversion terminee. Le fichier DWG se trouve dans ce dossier.
)
pause
