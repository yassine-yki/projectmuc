$ErrorActionPreference = 'Stop'
$folder = Split-Path -Parent $MyInvocation.MyCommand.Path
$manifestFile = Join-Path $folder 'delimitations.json'
$manifest = Get-Content -LiteralPath $manifestFile -Raw -Encoding UTF8 | ConvertFrom-Json
$dxf = Get-Item -LiteralPath (Join-Path $folder $manifest.sourceFile)
$dwg = Join-Path $folder $manifest.outputFile
$errorFile = Join-Path $folder 'ERREUR_CONVERSION.txt'
Remove-Item -LiteralPath $errorFile -Force -ErrorAction SilentlyContinue
$document = $null
try {
  Write-Host 'Ouverture du DXF original dans AutoCAD...'
  $autocad = New-Object -ComObject AutoCAD.Application
  $autocad.Visible = $true
  $lastOpenError = $null
  for ($attempt = 1; $attempt -le 10 -and -not $document; $attempt++) {
    try { $document = $autocad.Documents.Open($dxf.FullName, $false) }
    catch { $lastOpenError = $_; Start-Sleep -Seconds 2 }
  }
  if (-not $document) { throw $lastOpenError }
  Write-Host 'Creation des calques et des contours...'
  foreach ($layer in $manifest.layers) {
    try { $cadLayer = $document.Layers.Item([string]$layer.name) }
    catch { $cadLayer = $document.Layers.Add([string]$layer.name) }
    if ($layer.colorIndex -ge 1 -and $layer.colorIndex -le 255) { $cadLayer.Color = [int16]$layer.colorIndex }
  }
  foreach ($zone in $manifest.zones) {
    if ($zone.points.Count -lt 3) { continue }
    [double[]]$coordinates = [double[]]::new($zone.points.Count * 2)
    for ($index = 0; $index -lt $zone.points.Count; $index++) {
      $coordinates[$index * 2] = [double]$zone.points[$index].x
      $coordinates[$index * 2 + 1] = [double]$zone.points[$index].y
    }
    $polyline = $document.ModelSpace.AddLightWeightPolyline($coordinates)
    $polyline.Closed = $true
    $polyline.Layer = [string]$zone.layer
  }
  Write-Host 'Creation du fichier DWG...'
  $document.SaveAs($dwg, 64)
  Write-Host "DWG cree : $dwg"
} catch {
  ($_ | Format-List * -Force | Out-String) | Set-Content -LiteralPath $errorFile -Encoding UTF8
  Write-Host "Conversion impossible : $($_.Exception.Message)" -ForegroundColor Red
  Write-Host "Le detail est enregistre dans : $errorFile" -ForegroundColor Yellow
  exit 1
} finally {
  if ($document) { try { $document.Close($false) } catch {} }
}
